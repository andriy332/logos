function sum(){
	// let v = ['test']
	// let v1 = []
	
	// if(v1==v.test){
       // alert("� ������� 2 virno");
	   // result++;
	// }
	// else{
		// alert("Ne ���o");
	// }
// 
var c1 = document.getElementById("c1").value;
switch (c1){ 
  case '1996':
    alert('1: Ok')
    break;
    default:
      alert('1: No');
      break;
 }

var c2 = document.getElementById("c2").value;

switch (c2){ 
  case '1941':
    alert('2: Ok')
    break;
     default:
      alert('2: No');
      break;
 }


var c3 = document.getElementById("c3").value;
var a21 = "1995"

if (c3 = a21){
	alert('3: Ok');
}else{
    alert('3: No');
 }
 
// // switch (c4){ 
  // // case '9':
    // // alert('4: Ok')
    // // break;
    // // default:
      // // alert('4: No');
      // // break;
 // // }
 
// var c5 = document.getElementById("c5").value;
// var a55 = "9";

// if (a46 = a55){
    // alert('4: Ok');
// }else{
    // alert('4: no');
 // }
// }

var c4 = document.getElementById("c4").value;
var a21 = "1995"

switch (c4){ 
  case '9':
    alert('4: Ok')
    break;
    default:
      alert('4: No');
      break;
     }

var c5 = document.getElementById("c5").value;

switch (c5){ 
  case '2005':
    alert('5: Ok')
    break;
    default:
      alert('5: No');
      break;
   }


var c6 = document.getElementById("c6").value;
var f55 = "1998"

if(c6 = f55){
	alert('Ok');
 }else{
	alert('No');
 }

var c7 = document.getElementById("c7").value;
var f65 = "2013"

if(c7 = f65){
	alert('Ok');
 }else{
	alert('No');
 }

var c8 = document.getElementById("c8").value;
var f69 = "25"

if(c7 = f69){
	alert('Ok');
 }else{
	alert('No');
 }

var c9 = document.getElementById("c9").value;
var f70 = "7"

if(c9 = f70){
	alert('Ok');
 }else{
	alert('No');
 }
}

